/* Jacob Ohara
* 25 Feb 2024
* CS210
* write a program that reads a text file and prints frequency of items and names as well as writes to a new text file 
*/

#include <iostream>
#include <fstream> //included for reading and writing files
#include <map> //included to store item counts 
#include <string>
using namespace std;

class ItemCounter {
// define public and private sections
public:
	// create function to read file 
    void readFile(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            throw runtime_error("Unable to open file: " + filename);
        }

        string item;
        while (file >> item) {
            itemCount[item]++;
        }
    }

    // function to search in file 
    void searchItem(const string& item) { // use string as reference and item as parameter
        cout << item << " " << itemCount[item] << endl;
    }
    // function for printing all names and counts 
    void printCounts() {
        for (const auto& pair : itemCount) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    //function to print counts as histogram
    void printHistogram() { // New method to print a histogram of the counts
        for (const auto& pair : itemCount) { // referenced pair key and value 
            cout << pair.first; //print the key item name
            for (int i = 0; i < pair.second; i++) { // loop through values to print * instead of int 
                cout << "*";
            }
            cout << endl;
        }
    }

    // create function to write file
    void writeFile(const string& filename) { //reference string and filename
        ofstream file(filename);
        if (!file.is_open()) {
            throw runtime_error("Unable to open file"); // error handling 
        }
        //for loop to iterate through pairs and print the key and value which is item and number of times it appeas
        for (const auto& pair : itemCount) {
            file << pair.first << " " << pair.second << endl;
        }
    }

private:
    map<string, int> itemCount; // mapped as key and value stores string and int to be refererced
};

int main() {
	ItemCounter count; // instance for items 
	// read the input file and write to the new file for backup purposes 
    // print the counts for verification
    // write the file for backup
    try {
        count.readFile("U://finalProject//CS210_Project_Three_Input_File.txt");
        //count.printCounts(); used to test before writing to file 
        //writing to file 
        count.writeFile("U://finalProject//frequency.dat");

    }
    catch (const runtime_error& e) { // catch error using .ewhat() to display error message if unable to open file 
        cerr << e.what() << endl;
        return 1;
    }

    // variable for user input 
    int userInput = 0;

    //create loop to print menue and user options
    do {
        cout << "1: Search by item. " << endl;
        cout << "2: Print all items and counts. " << endl;
        cout << "3: Print all items and counts. as a histogram." << endl;
        cout << "4: Quit" << endl;
        cin >> userInput;

        if (userInput == 1) {
            string userString; // declare variable for user to search for an item
            cout << "Enter the Item you would like to search for: ";
            cin >> userString; // read user item
            count.searchItem(userString); // pass item as param through funciton 
       }
       
        //print all names and counts
        else if (userInput == 2) {
            count.printCounts(); //calls function used to test 
        }
        else if (userInput == 3) {
            count.printHistogram(); // calls function with no params 
        }
    } while (userInput != 4); // exits the loop 


	return 0;
}