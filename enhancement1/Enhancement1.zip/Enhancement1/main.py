"""
Inventory Counter

Jacob Ohara
24 May 2025
CS 499

This program reads a text file from the project directory. It generates graphical reports of the contents, counts
item frequency, and generates a new file containing items and counts.
"""

from collections import defaultdict
import matplotlib.pyplot as plt


class ItemCounter:
    """Counts the occurrences of items in a text file and provides methods for analysis and output"""

    def __init__(self):
        """
        Initializes an instance of ItemCounter.
        Creates a dictionary to count items using defaultdict.
        """
        self._item_count = defaultdict(int)

    def read_file(self, filename):
        """
        Reads a text file and counts occurrences of each item.

        Opens the specified file from the project directory. Raises an error if the file cannot be opened.
        For each line, splits items by whitespace, converts them to lowercase, and increments their count by 1.
        """
        file = None  # Predefine variable to ensure existence for all cases
        try:
            file = open(filename, 'r')
        except FileNotFoundError:
            raise RuntimeError(f"Unable to open file: {filename}")

        else:
            for line in file:
                for item in line.split():
                    item = item.lower()
                    self._item_count[item] += 1
        finally:
            if file:
                file.close()
            else:
                print("no file was opened")

    def search_item(self, item):
        """
        Searches for an item in inventory and prints its count or a message to indicate that item is not found in the
        inventory.

        :param item: the name of the item to search for
        :return: none - prints the result either item and the count or no item exists in the inventory
        """
        if self._item_count[item] == 0:
            print(f"'{item}' does not exist in the inventory.")
        else:
            print(f"{item} {self._item_count[item]}")

    def print_counts(self):
        """
        Loops through each item in the dictionary and prints the item along with the count
        :return: none - prints each message and associated count
        """
        for item, count in self._item_count.items():
            print(f"{item} {count}")

    def save_barchart_image(self, output_filename="Item Inventory.png"):
        """
        Saves a bar chart image displaying all inventory items and their counts.

        References
        Matplotlib bar chart documentation
        https://matplotlib.org/stable/gallery/lines_bars_and_markers/bar_demo.html
        """
        items = list(self._item_count.keys())
        counts = list(self._item_count.values())

        plt.figure()
        plt.bar(items, counts, color='blue')
        plt.xlabel('Items')
        plt.ylabel('Count')
        plt.title('All Items in Inventory')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        plt.savefig(output_filename)
        plt.close()
        print(f"Barchart saved as {output_filename}")

    def save_pie_chart_image(self, output_filename="Inventory Distribution.png"):
        """
        Creates and saves a pie chart image displaying all inventory items and their percentage share of the total.

        References
        Matplotlib pie chart documentation
        https://matplotlib.org/stable/gallery/pie_and_polar_charts/pie_features.html#sphx-glr-gallery-pie-and-polar-charts-pie-features-py
        """
        items = list(self._item_count.keys())
        counts = list(self._item_count.values())
        cmap = plt.colormaps['tab20']  # define a list of colors to use
        colors = [cmap(i / len(items)) for i in range(len(items))]  # assign each item with a different color

        plt.figure()
        plt.pie(
            counts,
            labels=items,
            autopct='%d%%',  # use whole number percentages
            startangle=0,
            colors=colors
        )
        plt.title("Inventory Distribution")
        plt.axis('equal')
        plt.tight_layout()
        plt.savefig(output_filename)
        plt.close()
        print(f"Pie chart saved as {output_filename}")

    def write_file(self, filename):
        """
        Writes item and count to a text file following format of item: count

        :param filename: string frequency.txt
        :return: none - writes to a new txt file and does not return a value
        """
        try:
            with open(filename, 'w') as file:
                for item, count in self._item_count.items():
                    file.write(f"{item}: {count}\n")
        except IOError:
            raise RuntimeError("Unable to open file")

    def item_menu(self):
        """
        Displays a menu for the user to interact with.
        Handles options to search, print, and create bar and pie charts.
        Loops menu until user decides to quit the application.
        """
        while True:
            print("\nMenu:")
            print("1: Search by item")
            print("2: Print all items and counts")
            print("3: Create a bar chart to show all items in the inventory")
            print("4: Create a pie chart distribution of all items in the inventory")
            print("5: Quit")

            try:
                user_input = int(input("Enter your choice: "))
            except ValueError:
                print("Invalid input. Please enter a number between 1 and 5.")
                continue

            if user_input == 1:
                user_string = input("Enter the item name to search for: ").strip().lower()
                self.search_item(user_string)

            elif user_input == 2:
                self.print_counts()

            elif user_input == 3:
                self.save_barchart_image()

            elif user_input == 4:
                self.save_pie_chart_image()

            elif user_input == 5:
                print("Program Exiting")
                break

            else:
                print("Please select a valid option: 1-5")


def main():
    """
    Main function to execute data processing.
    Initializes ItemCounter as an object, reads inventory data, writes the frequency
    each item appears in the document and launches an interactive menu prompt for the user.
    """
    count = ItemCounter()

    try:
        count.read_file("Inventory.txt")
        count.write_file("frequency.txt")

    except RuntimeError as e:
        print(e)
        return

    count.item_menu()

# -------------------- MAIN PROGRAM --------------------


if __name__ == "__main__":
    """Ensures script execution when directly called"""
    main()
