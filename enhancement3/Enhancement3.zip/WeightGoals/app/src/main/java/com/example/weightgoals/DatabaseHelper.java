package com.example.weightgoals;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import android.util.Log; // error logging

import java.nio.charset.StandardCharsets; //UTF-8 encoding
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.security.MessageDigest;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightGoals.db";
    private static final int DATABASE_VERSION = 1;

    // Table names
    public static final String TABLE_DAILY_WEIGHT = "daily_weight";
    private static final String TABLE_USER_LOGINS = "user_logins";
    private static final String TABLE_GOAL_WEIGHT = "goal_weight";

    // Columns for daily_weight
    public static final String COLUMN_ID = "_id";
    private static final String COLUMN_DATE = "date";
    public static final String COLUMN_WEIGHT = "weight";

    // Columns for user_logins
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Columns for goal_weight
    public static final String COLUMN_GOAL_WEIGHT = "goal_weight";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create daily_weight table
        String CREATE_TABLE_DAILY_WEIGHT = "CREATE TABLE " + TABLE_DAILY_WEIGHT + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_DATE + " TEXT,"
                + COLUMN_WEIGHT + " REAL)";
        db.execSQL(CREATE_TABLE_DAILY_WEIGHT);

        // Create user_logins table
        String CREATE_TABLE_USER_LOGINS = "CREATE TABLE " + TABLE_USER_LOGINS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT,"
                + COLUMN_PASSWORD + " TEXT)";
        db.execSQL(CREATE_TABLE_USER_LOGINS);

        // Create goal_weight table
        String CREATE_TABLE_GOAL_WEIGHT = "CREATE TABLE " + TABLE_GOAL_WEIGHT + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_GOAL_WEIGHT + " REAL)";
        db.execSQL(CREATE_TABLE_GOAL_WEIGHT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DAILY_WEIGHT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER_LOGINS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL_WEIGHT);
        onCreate(db);
    }

    // method for password hashing in the db
    // retrieved from https://docs.oracle.com/javase/8/docs/api/java/security/MessageDigest.html
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            Log.e("DatabaseHelper", "Hashing error", e);
            return null;
        }
    }

    // retrieved examples from https://developer.android.com/training/data-storage/sqlite
    // https://www.vogella.com/tutorials/AndroidSQLite/article.html
    // Method to insert daily weight data
    // implement input validation
    public boolean insertDailyWeight(String date, float weight) {
        if (date == null || date.trim().isEmpty()) {
            Log.e("DatabaseHelper", "Invalid input: There is not date");
            return false;
        }

        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(COLUMN_DATE, date);
            contentValues.put(COLUMN_WEIGHT, weight);

            long result = db.insert(TABLE_DAILY_WEIGHT, null, contentValues);
            return result != -1;
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Daily weight not accepted", e);
            return false;
        } finally {
            if (db != null && db.isOpen()) db.close();
        }
    }

    // Method to insert user login data
    // implement validation hashing logging and error handling
    public boolean insertUserLogin(String username, String password) {
        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            Log.e("DatabaseHelper", "Invalid input: No username or password present");
            return false;
        }

        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            String hashedPassword = hashPassword(password);
            if (hashedPassword == null) return false;

            contentValues.put(COLUMN_USERNAME, username);
            contentValues.put(COLUMN_PASSWORD, hashedPassword);

            long result = db.insert(TABLE_USER_LOGINS, null, contentValues);
            return result != -1;
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error inserting user login", e);
            return false;
        }
    }


    // Method to insert goal weight data
    //implement input validation
    public boolean insertGoalWeight(float goalWeight) {
        if (goalWeight <= 0) {
            Log.e("DatabaseHelper", "Invalid input: goal weight must be positive");
            return false;
        }

        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(COLUMN_GOAL_WEIGHT, goalWeight);

            long result = db.insert(TABLE_GOAL_WEIGHT, null, contentValues);
            return result != -1;
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error inserting goal weight", e);
            return false;
        } finally {
            if (db != null && db.isOpen()) db.close();
        }
    }

    // close all cursors from the callers and use input validation params
    // Method to retrieve user data
    // references from https://developer.android.com/training/data-storage/sqlite
    //

    public Cursor getUserData(String username) {
        if (username == null || username.trim().isEmpty()) {
            Log.e("DatabaseHelper", "Invalid input: username is empty");
            return null;
        }

        try {
            SQLiteDatabase db = this.getReadableDatabase();
            return db.query(TABLE_USER_LOGINS, null, COLUMN_USERNAME + "=?", new String[]{username}, null, null, null);
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error retrieving user data", e);
            return null;
        }
    }
    // Method to retrieve all weight entries
    public Cursor getAllWeightEntries() {
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            return db.query(TABLE_DAILY_WEIGHT, null, null, null, null, null, COLUMN_DATE + " ASC");
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error retrieving weight entries", e);
            return null;
        }
    }
    // Method to retrieve goal weight
    public Cursor getGoalWeight() {
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            return db.query(TABLE_GOAL_WEIGHT, null, null, null, null, null, null);
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error retrieving goal weight", e);
            return null;
        }
    }


}

