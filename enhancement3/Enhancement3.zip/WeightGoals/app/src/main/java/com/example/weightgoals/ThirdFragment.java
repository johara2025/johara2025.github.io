package com.example.weightgoals;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class ThirdFragment extends Fragment {

    private EditText weightInput;
    private DatabaseHelper databaseHelper;

    // inlfate views and initialize db and listener for confirmation button
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_third, container, false);

        // Initialize views
        weightInput = view.findViewById(R.id.weightInput);
        Button confirmButton = view.findViewById(R.id.confirmButton);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(getContext());

        // Set listener for confirm button
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addGoalWeight();
            }
        });

        return view;
    }

    // method to add a weight goal
    private void addGoalWeight() {
        String goalWeightStr = weightInput.getText().toString().trim();

        // check if input is empty
        if (TextUtils.isEmpty(goalWeightStr)) {
            // tell user to enter a weight goal
            Toast.makeText(getContext(), "Please enter your goal weight", Toast.LENGTH_SHORT).show();
            return;
        }

        // implement try and catch for exception handling
        try {
            // change weight into float
            float goalWeight = Float.parseFloat(goalWeightStr);
            // put weight into the db
            boolean result = databaseHelper.insertGoalWeight(goalWeight);
            // if success print success
            if (result) {
                Toast.makeText(getContext(), "Goal weight saved successfully", Toast.LENGTH_SHORT).show();
                // return to previous page
                navigateToFirstFragment();
            } else {
                Toast.makeText(getContext(), "Failed to save goal weight", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            // show message if weight not valid
            Toast.makeText(getContext(), "Invalid weight format", Toast.LENGTH_SHORT).show();
        }
    }

    // method to navigatte back to fragment_first
    private void navigateToFirstFragment() {
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, new FirstFragment());
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
}


