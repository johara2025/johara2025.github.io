package com.example.weightgoals;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class FirstFragment extends Fragment {

    private RecyclerView weightHistoryRecyclerView;
    private Button addEntryButton, deleteEntryButton;
    private FloatingActionButton floatingActionButton;
    private DatabaseHelper databaseHelper;
    private WeightHistoryAdapter weightHistoryAdapter;
    private ArrayList<WeightEntry> weightEntries;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        // Initialize views
        weightHistoryRecyclerView = view.findViewById(R.id.weightHistoryRecyclerView);
        addEntryButton = view.findViewById(R.id.addEntryButton);
        deleteEntryButton = view.findViewById(R.id.deleteEntryButton);
        floatingActionButton = view.findViewById(R.id.floatingActionButton3);
        databaseHelper = new DatabaseHelper(getContext());

        // Load all weight entries from DB
        weightEntries = loadWeightEntries();

        // Set up RecyclerView
        weightHistoryRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        weightHistoryAdapter = new WeightHistoryAdapter(getContext(), weightEntries, databaseHelper);
        weightHistoryRecyclerView.setAdapter(weightHistoryAdapter);

        // Set listener for the add entry button
        addEntryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to SecondFragment
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, new SecondFragment())
                        .addToBackStack(null)
                        .commit();
            }
        });

       // set listener for the delete button and functionality
        deleteEntryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle delete entry logic
                weightHistoryAdapter.deleteSelectedEntries();
            }
        });

        // set listener for the FAB
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to ThirdFragment
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, new ThirdFragment())
                        .addToBackStack(null)
                        .commit();
            }
        });

        return view;
    }

    // load weight entries into array
    private ArrayList<WeightEntry> loadWeightEntries() {
        // create list to store weight
        ArrayList<WeightEntry> entries = new ArrayList<>();
        Cursor cursor = databaseHelper.getAllWeightEntries();

        // get id, weight, date, create new entry to add to list
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("_id"));
                String date = cursor.getString(cursor.getColumnIndex("date"));
                float weight = cursor.getFloat(cursor.getColumnIndex("weight"));
                entries.add(new WeightEntry(id, date, weight));
            } while (cursor.moveToNext());

            // closer cursor
            cursor.close();
        }

        // return the list of entries
        return entries;
    }
}



