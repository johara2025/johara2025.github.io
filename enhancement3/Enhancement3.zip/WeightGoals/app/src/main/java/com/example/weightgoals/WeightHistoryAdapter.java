package com.example.weightgoals;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

// class used for the recycle viewer to display all past weight entries
public class WeightHistoryAdapter extends RecyclerView.Adapter<WeightHistoryAdapter.ViewHolder> {

    private Context context;
    private ArrayList<WeightEntry> weightEntries;
    private DatabaseHelper databaseHelper;

    public WeightHistoryAdapter(Context context, ArrayList<WeightEntry> weightEntries, DatabaseHelper databaseHelper) {
        this.context = context;
        this.weightEntries = weightEntries;
        this.databaseHelper = databaseHelper;
    }

    // method to create views
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.weight_history_item, parent, false);
        return new ViewHolder(view);
    }

    // method to combine past weights to views
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // get weight at position
        WeightEntry weightEntry = weightEntries.get(holder.getAdapterPosition());
        // set date and weight vals
        holder.dateTextView.setText(weightEntry.getDate());
        holder.weightTextView.setText(String.valueOf(weightEntry.getWeight()));

        // create delete button listener
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // delete weight entry and update the views
                deleteEntry(weightEntry);
                int currentPosition = holder.getAdapterPosition();
                weightEntries.remove(currentPosition);
                notifyItemRemoved(currentPosition);
                notifyItemRangeChanged(currentPosition, weightEntries.size());
            }
        });
    }


    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView, weightTextView;
        Button deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            weightTextView = itemView.findViewById(R.id.weightTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    // method to delete past weight entry from db
    private void deleteEntry(WeightEntry weightEntry) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        // delete entry based on ID
        int rowsAffected = db.delete(DatabaseHelper.TABLE_DAILY_WEIGHT, DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(weightEntry.getId())});
        // verify deletion success
        if (rowsAffected > 0) {
            Toast.makeText(context, "Entry deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Failed to delete entry", Toast.LENGTH_SHORT).show();
        }
    }
    // delete all weights from the DB
    public void deleteSelectedEntries() {
        for (int i = 0; i < weightEntries.size(); i++) {
            WeightEntry entry = weightEntries.get(i);
            deleteEntry(entry);
        }
        weightEntries.clear();
        notifyDataSetChanged();
    }
}

