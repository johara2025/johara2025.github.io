package com.example.weightgoals;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightGoals.db";
    private static final int DATABASE_VERSION = 1;

    // Table names
    public static final String TABLE_DAILY_WEIGHT = "daily_weight";
    private static final String TABLE_USER_LOGINS = "user_logins";
    private static final String TABLE_GOAL_WEIGHT = "goal_weight";

    // Columns for daily_weight
    public static final String COLUMN_ID = "_id";
    private static final String COLUMN_DATE = "date";
    public static final String COLUMN_WEIGHT = "weight";

    // Columns for user_logins
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Columns for goal_weight
    public static final String COLUMN_GOAL_WEIGHT = "goal_weight";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create daily_weight table
        String CREATE_TABLE_DAILY_WEIGHT = "CREATE TABLE " + TABLE_DAILY_WEIGHT + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_DATE + " TEXT,"
                + COLUMN_WEIGHT + " REAL)";
        db.execSQL(CREATE_TABLE_DAILY_WEIGHT);

        // Create user_logins table
        String CREATE_TABLE_USER_LOGINS = "CREATE TABLE " + TABLE_USER_LOGINS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT,"
                + COLUMN_PASSWORD + " TEXT)";
        db.execSQL(CREATE_TABLE_USER_LOGINS);

        // Create goal_weight table
        String CREATE_TABLE_GOAL_WEIGHT = "CREATE TABLE " + TABLE_GOAL_WEIGHT + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_GOAL_WEIGHT + " REAL)";
        db.execSQL(CREATE_TABLE_GOAL_WEIGHT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DAILY_WEIGHT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER_LOGINS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL_WEIGHT);
        onCreate(db);
    }

    // Method to insert daily weight data
    public boolean insertDailyWeight(String date, float weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_DATE, date);
        contentValues.put(COLUMN_WEIGHT, weight);
        long result = db.insert(TABLE_DAILY_WEIGHT, null, contentValues);
        return result != -1;
    }

    // Method to insert user login data
    public boolean insertUserLogin(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USERNAME, username);
        contentValues.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USER_LOGINS, null, contentValues);
        return result != -1;
    }

    // Method to insert goal weight data
    public boolean insertGoalWeight(float goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_GOAL_WEIGHT, goalWeight);
        long result = db.insert(TABLE_GOAL_WEIGHT, null, contentValues);
        return result != -1;
    }

    // Method to retrieve user data
    public Cursor getUserData(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_USER_LOGINS, null, COLUMN_USERNAME + "=?", new String[]{username}, null, null, null);
    }
    // Method to retrieve all weight entries
    public Cursor getAllWeightEntries() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_DAILY_WEIGHT, null, null, null, null, null, COLUMN_DATE + " ASC");
    }
    // Method to retrieve goal weight
    public Cursor getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_GOAL_WEIGHT, null, null, null, null, null, null);
    }


}

