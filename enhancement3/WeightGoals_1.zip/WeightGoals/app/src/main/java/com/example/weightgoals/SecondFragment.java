package com.example.weightgoals;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import java.util.Calendar;

public class SecondFragment extends Fragment {

    private static final String TAG = "SecondFragment";

    private EditText dateInput;
    private EditText weightInput;
    private DatabaseHelper databaseHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout
        View view = inflater.inflate(R.layout.fragment_second, container, false);

        // init views and dbhelper class
        dateInput = view.findViewById(R.id.dateInput);
        weightInput = view.findViewById(R.id.weightInput);
        Button confirmButton = view.findViewById(R.id.confirmButton);
        databaseHelper = new DatabaseHelper(getActivity());

        // Set OnClickListener for the date input
        dateInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // show dialog to pick to date
                showDatePickerDialog();
            }
        });

        // set listener for confirm button
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // implement try and catch for excepion handling for crashes after confirmation
                try {
                    // get the input and trim fields
                    String date = dateInput.getText().toString().trim();
                    String weightStr = weightInput.getText().toString().trim();

                    // try to log values to debug crash issues
                    Log.d(TAG, "Date: " + date);
                    Log.d(TAG, "Weight: " + weightStr);

                    // check if any fields are empty
                    if (date.isEmpty() || weightStr.isEmpty()) {
                        Toast.makeText(getActivity(), "Please enter both date and weight", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // parse weight into float
                    float weight = Float.parseFloat(weightStr);
                    Log.d(TAG, "Parsed Weight: " + weight);

                    // insert daily data into the db
                    boolean insertSuccess = databaseHelper.insertDailyWeight(date, weight);
                    Log.d(TAG, "Insert Success: " + insertSuccess);

                    // show toast messages based on data inserted
                    if (insertSuccess) {
                        Toast.makeText(getActivity(), "Data saved successfully", Toast.LENGTH_SHORT).show();
                        // Navigate back to first fragment
                        NavHostFragment.findNavController(SecondFragment.this).navigate(R.id.action_SecondFragment_to_FirstFragment);
                    } else {
                        Toast.makeText(getActivity(), "Failed to save data", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error in confirmButton onClick: ", e);
                    Toast.makeText(getActivity(), "An error occurred. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }

    // method for displaying message to pick a date
    private void showDatePickerDialog() {
        try {
            // Get current date
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            // create new date message
            DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    // Format and set the date in the EditText
                    dateInput.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                }
            }, year, month, day);

            // display date select message
            datePickerDialog.show();
        } catch (Exception e) {
            // implement exception handling for debugging of crash issues
            Log.e(TAG, "Error in showDatePickerDialog: ", e);
            Toast.makeText(getActivity(), "An error occurred while selecting the date. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }
}



