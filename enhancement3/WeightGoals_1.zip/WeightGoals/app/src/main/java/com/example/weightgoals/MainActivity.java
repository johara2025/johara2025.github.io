package com.example.weightgoals;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.telephony.SmsManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;

    private EditText usernameEditText, passwordEditText;
    private Button loginButton, createAccountButton, sendSmsButton;
    private TextView permissionStatusTextView;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);
        sendSmsButton = findViewById(R.id.sendSmsButton);
        permissionStatusTextView = findViewById(R.id.permissionStatus);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Set listener for login button click
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // call the login method to log users in
                loginUser();
            }
        });

        // set listener for create account button click
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //call method to create account setup for login
                createAccount();
            }
        });

        // set up listener for goal weight
        sendSmsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // check if goal weight is reached then send the SMS message to user
                checkGoalWeight();
            }
        });
    }

    //method to login the user
    private void loginUser() {
        // get username and passowrd
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // if username or password are empty display text then stop execution
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // get username and password from the database
        Cursor cursor = databaseHelper.getUserData(username);
        if (cursor != null && cursor.moveToFirst()) {
            // Check if password column exists
            int passwordColumnIndex = cursor.getColumnIndex("password");
            if (passwordColumnIndex != -1) {
                // get stored password from db
                String dbPassword = cursor.getString(passwordColumnIndex);
                if (password.equals(dbPassword)) {
                    Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                    //on successful login move to main app screen
                    navigateToFirstFragment();
                } else {
                    Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Password column not found", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
        }
    }

    // method to create user accounts
    private void createAccount() {
        //take username and password provided by user
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        //ensure both fields are filled out if not then prompted to enter both
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

       // insert username and password into db for future use
        boolean result = databaseHelper.insertUserLogin(username, password);
        if (result) {
            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
            navigateToFirstFragment();
        } else {
            Toast.makeText(this, "Account creation failed", Toast.LENGTH_SHORT).show();
        }
    }

    // Navigate to FirstFragment when login is successful
    private void navigateToFirstFragment() {
        // get rid of initial UI
        findViewById(R.id.welcomeMessage).setVisibility(View.GONE);
        findViewById(R.id.usernameLabel).setVisibility(View.GONE);
        findViewById(R.id.username).setVisibility(View.GONE);
        findViewById(R.id.passwordLabel).setVisibility(View.GONE);
        findViewById(R.id.password).setVisibility(View.GONE);
        findViewById(R.id.loginButton).setVisibility(View.GONE);
        findViewById(R.id.createAccountButton).setVisibility(View.GONE);
        findViewById(R.id.permissionStatus).setVisibility(View.GONE);
        findViewById(R.id.sendSmsButton).setVisibility(View.GONE);
        findViewById(R.id.fragment_container).setVisibility(View.VISIBLE);

        // replace current fragment
        Fragment firstFragment = new FirstFragment();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, firstFragment)
                // allow backwards nav
                .addToBackStack(null)
                .commit();
    }

    // Get goal weight from the database
    private float getGoalWeightFromDB() {
        Cursor cursor = databaseHelper.getGoalWeight();
        if (cursor != null && cursor.moveToFirst()) {
            // return goal weight from the db
            return cursor.getFloat(cursor.getColumnIndex(DatabaseHelper.COLUMN_GOAL_WEIGHT));
        }
        // if goal weight not found return -1
        return -1;
    }

    // Send SMS message
    private void sendSMS(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_SHORT).show();
    }

    // Check goal weight and send SMS if the goal is reached
    private void checkGoalWeight() {
        // get all weight entries from the DB
        Cursor cursor = databaseHelper.getAllWeightEntries();
        // get goal weight from the db
        float goalWeight = getGoalWeightFromDB();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                float dailyWeight = cursor.getFloat(cursor.getColumnIndex(DatabaseHelper.COLUMN_WEIGHT));
                // if recorded weight == goal weight
                if (dailyWeight == goalWeight) {
                    // display SMS message
                    sendSMS("1234567890", "GOAL WEIGHT REACHED!"); // exit once message sent
                    break;
                }
            } while (cursor.moveToNext());
        }
    }
}






